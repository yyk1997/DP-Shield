import os
import math
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import transforms
# from datasets import load_dataset
from torchvision import datasets, transforms
from diffusers import DDPMPipeline, DDPMScheduler
from accelerate import Accelerator
from tqdm.auto import tqdm
from PIL import Image
from torch.optim.lr_scheduler import CosineAnnealingLR
from cleanfid import fid
from torch.optim.lr_scheduler import LambdaLR

########################################
# 配置部分
########################################
model_name = 'google/ddpm-cifar10-32'
output_dir = "./models/ddpm-gtsrb-finetuned_2"
data_dir = './data'
batch_size = 64
learning_rate = 1e-4
num_epochs = 50
save_every = 5  # 每个epoch后保存一次模型和pipeline
inference_steps = 1000 # 推理时扩散过程的步数
lr_warmup_steps = 500
gradient_accumulation_steps = 1  # 梯度累积步数

pipeline = DDPMPipeline.from_pretrained(output_dir).to("cuda")

image = pipeline().images[0]

print(image)


os.makedirs(output_dir, exist_ok=True)

########################################
# 数据准备与预处理
########################################


data_transform = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomCrop(32, padding=4),
    transforms.ToTensor(),
])

dataset = datasets.CIFAR10(os.path.join(data_dir, 'cifar10'), train = True, transform=data_transform,
                                    download=True)
img_size = 32
num_classes = 43
# dataset = load_dataset("gtsrb", split="train")

def collate_fn(batch):
    # batch是列表，每个元素是(img, label)
    # 我们只需要img用于DDPM的无条件训练，不需要label
    images = [item[0] for item in batch]  # item[0]是图像, item[1]是label
    images = torch.stack(images, dim=0)  # [B,C,H,W]
    return {"pixel_values": images}

# def transform_examples(examples):
#     images = [preprocess(img.convert("RGB")) for img in examples["image"]]
#     return {"pixel_values": images}
#
# dataset = dataset.map(transform_examples, batched=True)
# dataset.set_format(type="torch", columns=["pixel_values"])

dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True, collate_fn=collate_fn)

real_images_dir = os.path.join(output_dir, "real_images_for_fid")
os.makedirs(real_images_dir, exist_ok=True)

test_set = datasets.CIFAR10(os.path.join(data_dir, 'cifar10'), train=False, transform=data_transform, download=True)
# 假设抽取1000张测试集图像作为FID真实参考
num_real_samples = 1000
test_loader = DataLoader(test_set, batch_size=64, shuffle=True, drop_last=False)

count = 0
if len(os.listdir(real_images_dir)) < num_real_samples:
    for batch_data in test_loader:
        imgs = batch_data[0]  # (B,C,H,W)
        for i in range(imgs.shape[0]):
            if count >= num_real_samples:
                break
            img = imgs[i]
            img_np = (img.numpy().transpose(1,2,0)*255).astype("uint8")
            Image.fromarray(img_np).save(os.path.join(real_images_dir, f"real_{count}.png"))
            count += 1
        if count >= num_real_samples:
            break
print(f"Collected {count} real images for FID reference at {real_images_dir}")




########################################
# 加载预训练模型与调度器
########################################
pipeline = DDPMPipeline.from_pretrained(model_name).to("cuda")
unet = pipeline.unet
scheduler = DDPMScheduler.from_config(pipeline.scheduler.config)


# 冻结部分权重
for param in unet.parameters():
    param.requires_grad = True



optimizer = torch.optim.AdamW(unet.parameters(), lr=learning_rate, weight_decay = 0.01)

# 自定义学习率调度器
def lr_lambda(current_step):
    if current_step < lr_warmup_steps:
        return float(current_step) / float(max(1, lr_warmup_steps))
    return max(0.0, float(num_epochs * len(dataloader) - current_step) / float(max(1, num_epochs * len(dataloader) - lr_warmup_steps)))

lr_scheduler = LambdaLR(optimizer, lr_lambda)


########################################
# 使用Accelerate加速训练
########################################
accelerator = Accelerator(mixed_precision="fp16")  # 可根据需要选择"no"或"fp16"
unet, optimizer, dataloader = accelerator.prepare(unet, optimizer, dataloader)

unet.train()

########################################
# 训练循环
########################################
global_step = 0

# 函数：生成样本保存，并计算FID
def evaluate_fid(pipeline, epoch):
    # 生成1000张样本用于FID计算（与real_images同数）
    generated_images_dir = os.path.join(output_dir, f"epoch-{epoch+1}-generated")
    os.makedirs(generated_images_dir, exist_ok=True)
    num_gen_samples = 1000
    batch_gen = 1000  # 每次生成50张，分多次完成

    pipeline.unet.eval()
    with torch.no_grad(), torch.autocast("cuda", enabled=torch.cuda.is_available()):
        for i in range(num_gen_samples // batch_gen):
            sample_images = pipeline(
                num_inference_steps=inference_steps,
                batch_size=batch_gen,
                output_type="tensor"
            ).images

            sample_images = torch.tensor(sample_images).clamp(0,1).cpu().numpy()
            for j, img_array in enumerate(sample_images):
                img = Image.fromarray((img_array*255).astype("uint8"))
                img.save(os.path.join(generated_images_dir, f"gen_{i*batch_gen+j}.png"))

    # 计算FID
    fid_score = fid.compute_fid(real_images_dir, generated_images_dir)
    accelerator.print(f"Epoch {epoch+1}: FID = {fid_score:.4f}")




for epoch in range(num_epochs):
    progress_bar = tqdm(dataloader, desc=f"Epoch {epoch}", disable=not accelerator.is_local_main_process)
    for step, batch in enumerate(progress_bar):
        images = batch["pixel_values"].to("cuda")
        # 映射到[-1,1]
        images = images * 2.0 - 1.0

        # 随机 timestep
        batch_size_current = images.shape[0]
        timesteps = torch.randint(0, scheduler.num_train_timesteps, (batch_size_current,), device=images.device).long()

        noise = torch.randn_like(images)
        noisy_images = scheduler.add_noise(images, noise, timesteps)

        with accelerator.autocast():
            noise_pred = unet(noisy_images, timesteps)["sample"]
            loss = F.mse_loss(noise_pred, noise)
            loss = loss / gradient_accumulation_steps  # 梯度累积

        optimizer.zero_grad()
        accelerator.backward(loss)

        if (step + 1) % gradient_accumulation_steps == 0:
            optimizer.step()
            lr_scheduler.step()
            global_step += 1


        if step % 100 == 0 and accelerator.is_local_main_process:
            progress_bar.set_postfix({"loss": loss.item(), "step": global_step})

    # 每个epoch结束后保存模型
    if accelerator.is_local_main_process and ((epoch + 1) % save_every == 0):
        accelerator.wait_for_everyone()
        unet.save_pretrained(os.path.join(output_dir, f"epoch-{epoch+1}-unet"))
        scheduler.save_pretrained(os.path.join(output_dir, f"epoch-{epoch+1}-scheduler"))
        # 同时保存整个pipeline，更新 pipeline 的 unet 和 scheduler
        pipeline.unet = unet
        pipeline.scheduler = scheduler
        pipeline.save_pretrained(os.path.join(output_dir, f"epoch-{epoch+1}-pipeline"))


    evaluate_fid(pipeline, epoch)



accelerator.print("Training finished successfully!")

########################################
# 推理（生成样本）
########################################
# 完成训练后，我们从保存的pipeline加载模型进行推理
# 假设我们使用最后一个epoch保存的pipeline
final_pipeline_path = os.path.join(output_dir, f"epoch-{num_epochs}-pipeline")
inference_pipeline = DDPMPipeline.from_pretrained(final_pipeline_path, torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32)
inference_pipeline.to(accelerator.device)  # 将pipeline放到GPU上

inference_pipeline.unet.eval()

# 生成若干张样本
num_samples = 8
# 无条件生成，只需给出要生成的张数
with torch.autocast("cuda", enabled=torch.cuda.is_available()):
    # 调用pipeline生成 num_samples张32x32图像
    # DDPM pipeline的__call__通常不需要条件输入，直接生成
    images = inference_pipeline(num_inference_steps=inference_steps, batch_size=num_samples, output_type="tensor").images
    # images是一个tensor，形状[batch, C, H, W]，数值范围为[-1,1]

images = (images / 2 + 0.5).clamp(0,1)  # 映射回[0,1]
images = images.cpu().permute(0,2,3,1).numpy()  # (B,H,W,C)

# 将生成的图像保存为png供查看
save_images_dir = os.path.join(output_dir, "generated_samples")
os.makedirs(save_images_dir, exist_ok=True)
for i, img_array in enumerate(images):
    img = Image.fromarray((img_array*255).astype("uint8"))
    img.save(os.path.join(save_images_dir, f"sample_{i}.png"))

accelerator.print(f"Generated samples saved to {save_images_dir}")