import matplotlib.pyplot as plt

# Define the fixed x-axis values
x_fixed = [10, 30, 50, 70, 100, 130, 150, 170, 200]

# Define the y-values for each line
y1 = [0.7355, 0.53975, 0.32025, 0.1595, 0, 0, 0, 0, 0]  # Line 1 data with \sigma_t=3.0
y2 = [0.7545, 0.55937, 0.37088, 0.22812, 0.07487, 0.01013, 0, 0, 0]  # Line 2 data with \sigma_t=5.0
y3 = [0.7565, 0.536, 0.35663, 0.23763, 0.08837, 0.02388, 0.00413, 0, 0]  # Line 3 data with \sigma_t=8.0
y4 = [0.7555, 0.50975, 0.32425, 0.22037, 0.0795, 0.023, 0.00487, 0.00025, 0]  # Line 4 data with \sigma_t=10.0

# Create a new figure
plt.figure(figsize=(8, 6))

# Plot the four lines with their respective labels
plt.plot(range(len(x_fixed)), y1, label=r'$\sigma_t=3.0$', color='orange')
plt.plot(range(len(x_fixed)), y2, label=r'$\sigma_t=5.0$', color='gold')
plt.plot(range(len(x_fixed)), y3, label=r'$\sigma_t=8.0$', color='blue')
plt.plot(range(len(x_fixed)), y4, label=r'$\sigma_t=10.0$', color='green')

# Add labels for the axes and the title
plt.xlabel(r"$r_s$")  # x-axis label as r_s (mathematical symbol)
plt.ylabel("Certified Accuracy")  # y-axis label
plt.title("Comparison of Multiple Lines with Fixed $r_s$ Values")

# Set the x-ticks to the fixed values with equal spacing
plt.xticks(range(len(x_fixed)), x_fixed)

# Display the legend
plt.legend()

# Add grid lines for better readability
plt.grid(True)

# Show the plot
plt.show()