'''codes used to train backdoored models on poisoned dataset
'''
import argparse
import os, sys
import time
from tqdm import tqdm
from utils import default_args, imagenet
from torch.cuda.amp import autocast, GradScaler
import numpy as np
from scipy.stats import norm

parser = argparse.ArgumentParser()
parser.add_argument('-dataset', type=str, required=False,
                    default=default_args.parser_default['dataset'],
                    choices=default_args.parser_choices['dataset'])
parser.add_argument('-poison_type', type=str, required=False,
                    default='none',
                    choices=default_args.parser_choices['poison_type'])
parser.add_argument('-poison_rate', type=float, required=False,
                    choices=default_args.parser_choices['poison_rate'],
                    default=default_args.parser_default['poison_rate'])
parser.add_argument('-cover_rate', type=float, required=False,
                    choices=default_args.parser_choices['cover_rate'],
                    default=default_args.parser_default['cover_rate'])
parser.add_argument('-ember_options', type=str, required=False,
                    choices=['constrained', 'unconstrained', 'none'],
                    default='unconstrained')
parser.add_argument('-alpha', type=float, required=False,
                    default=default_args.parser_default['alpha'])
parser.add_argument('-test_alpha', type=float, required=False, default=None)
parser.add_argument('-trigger', type=str, required=False,
                    default=None)
parser.add_argument('-no_aug', default=False, action='store_true')
parser.add_argument('-no_normalize', default=False, action='store_true')
parser.add_argument('-devices', type=str, default='1')
parser.add_argument('-log', default=False, action='store_true')
parser.add_argument('-seed', type=int, required=False, default=default_args.seed)

args = parser.parse_args()
os.environ["CUDA_VISIBLE_DEVICES"] = "%s" % args.devices

# 以下参数与backdoor 相关
args.dataset = "cifar10"
args.poison_type = "badnet"
args.poison_rate = 0.050
#args.cover_rate = 0.005
# args.alpha = 0.2
# args.trigger = "badnet_patch4_dup_32.png"



# 以下参数与certified相关
args.input_sigma = 1.0
args.delta = 3.0
args.N_m = 10
args.eta = 0.001

# args.certified_method = 'DP'
args.certified_method = 'hypothesis'

# args.confi_interval_method = 'simuEM'
args.confi_interval_metod = 'heof'

# args.inference_method = 'multinomial_label'
args.inference_method = 'probability_scores'
args.rad = (0.0, 0.05, 0.1, 0.2, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0)

import config
from torchvision import datasets, transforms
from torch import nn
import torch
from utils import supervisor, tools


if args.trigger is None:
    if args.dataset != 'imagenet':
        args.trigger = config.trigger_default[args.poison_type]
    elif args.dataset == 'imagenet':
        args.trigger = imagenet.triggers[args.poison_type]

all_to_all = False
if args.poison_type == 'badnet_all_to_all':
    all_to_all = True

tools.setup_seed(args.seed)

if args.log:
    out_path = 'logs'
    if not os.path.exists(out_path): os.mkdir(out_path)
    out_path = os.path.join(out_path, '%s_seed=%s' % (args.dataset, args.seed))
    if not os.path.exists(out_path): os.mkdir(out_path)
    out_path = os.path.join(out_path, 'base')
    if not os.path.exists(out_path): os.mkdir(out_path)
    out_path = os.path.join(out_path, '%s_%s.out' % (
    supervisor.get_dir_core(args, include_poison_seed=config.record_poison_seed), 'no_aug' if args.no_aug else 'aug'))
    fout = open(out_path, 'w')
    ferr = open('/dev/null', 'a')
    sys.stdout = fout
    sys.stderr = ferr

# 定义对于cifar10数据集的归一化操作
if args.dataset == 'cifar10':

    data_transform_aug = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomCrop(32, 4),
        transforms.ToTensor(),
        transforms.Normalize([0.4914, 0.4822, 0.4465], [0.247, 0.243, 0.261]),
    ])

    data_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([0.4914, 0.4822, 0.4465], [0.247, 0.243, 0.261])
    ])
# 定义对于gtsrb数据集的归一化操作
elif args.dataset == 'gtsrb':

    data_transform_aug = transforms.Compose([
        transforms.RandomRotation(15),
        transforms.ToTensor(),
        transforms.Normalize((0.3337, 0.3064, 0.3171), (0.2672, 0.2564, 0.2629))
    ])

    data_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.3337, 0.3064, 0.3171), (0.2672, 0.2564, 0.2629))
    ])

elif args.dataset == 'imagenet':
    print('[ImageNet]')

elif args.dataset == 'ember':
    print('[Non-image Dataset] Ember')
else:
    raise NotImplementedError('dataset %s not supported' % args.dataset)

# 定义模型训练阶段各重要参数，包括epoch, learning_rate, batch_size等
if args.dataset == 'cifar10':

    num_classes = 10
    arch = config.arch[args.dataset]
    momentum = 0.9
    weight_decay = 1e-4
    epochs = 100
    milestones = torch.tensor([50, 75])
    learning_rate = 0.1
    batch_size = 512

elif args.dataset == 'gtsrb':

    num_classes = 43
    arch = config.arch[args.dataset]
    momentum = 0.9
    weight_decay = 1e-4
    epochs = 100
    milestones = torch.tensor([30, 60])
    learning_rate = 0.01
    batch_size = 128

elif args.dataset == 'imagenet':

    num_classes = 1000
    arch = config.arch[args.dataset]
    momentum = 0.9
    weight_decay = 1e-4
    epochs = 90
    milestones = torch.tensor([30, 60])
    learning_rate = 0.1
    batch_size = 256

elif args.dataset == 'ember':

    num_classes = 2
    arch = config.arch[args.dataset]
    momentum = 0.9
    weight_decay = 1e-6
    epochs = 10
    learning_rate = 0.1
    milestones = torch.tensor([])
    batch_size = 512

else:

    print('<Undefined Dataset> Dataset = %s' % args.dataset)
    raise NotImplementedError('<To Be Implemented> Dataset = %s' % args.dataset)

if args.dataset == 'imagenet':
    kwargs = {'num_workers': 32, 'pin_memory': True}
else:
    kwargs = {'num_workers': 4, 'pin_memory': True}

# Set Up Poisoned Set
# 读入中毒数据集，构造poisoned_set_loader
if args.dataset != 'ember' and args.dataset != 'imagenet':
    poison_set_dir = supervisor.get_poison_set_dir(args)
    poisoned_set_img_dir = os.path.join(poison_set_dir, 'data')
    poisoned_set_label_path = os.path.join(poison_set_dir, 'labels')
    poison_indices_path = os.path.join(poison_set_dir, 'poison_indices')
    poison_indices = torch.load(poison_indices_path)

    print('dataset : %s' % poisoned_set_img_dir)

    poisoned_set = tools.IMG_Dataset(data_dir=poisoned_set_img_dir,
                                     label_path=poisoned_set_label_path,
                                     transforms=data_transform if args.no_aug else data_transform_aug)

    poisoned_set_loader = torch.utils.data.DataLoader(
        poisoned_set,
        batch_size=batch_size, shuffle=True, worker_init_fn=tools.worker_init, **kwargs)

elif args.dataset == 'imagenet':

    poison_set_dir = supervisor.get_poison_set_dir(args)
    poison_indices_path = os.path.join(poison_set_dir, 'poison_indices')
    poisoned_set_img_dir = os.path.join(poison_set_dir, 'data')
    print('dataset : %s' % poison_set_dir)

    poison_indices = torch.load(poison_indices_path)

    root_dir = '/path_to_imagenet/'
    train_set_dir = os.path.join(root_dir, 'train')
    test_set_dir = os.path.join(root_dir, 'val')

    from utils import imagenet

    poisoned_set = imagenet.imagenet_dataset(directory=train_set_dir, poison_directory=poisoned_set_img_dir,
                                             poison_indices=poison_indices, target_class=imagenet.target_class,
                                             num_classes=1000)

    poisoned_set_loader = torch.utils.data.DataLoader(
        poisoned_set,
        batch_size=batch_size, shuffle=True, worker_init_fn=tools.worker_init, **kwargs)

else:
    poison_set_dir = os.path.join('poisoned_train_set', 'ember', args.ember_options)
    poison_indices_path = os.path.join(poison_set_dir, 'poison_indices')

    # stats_path = os.path.join('data', 'ember', 'stats')
    poisoned_set = tools.EMBER_Dataset(x_path=os.path.join(poison_set_dir, 'watermarked_X.npy'),
                                       y_path=os.path.join(poison_set_dir, 'watermarked_y.npy'))
    print('dataset : %s' % poison_set_dir)

    poisoned_set_loader = torch.utils.data.DataLoader(
        poisoned_set,
        batch_size=batch_size, shuffle=True, worker_init_fn=tools.worker_init, **kwargs)

# 设置测试及评估数据
if args.dataset != 'ember' and args.dataset != 'imagenet':

    # Set Up Test Set for Debug & Evaluation
    test_set_dir = os.path.join('clean_set', args.dataset, 'test_split')
    test_set_img_dir = os.path.join(test_set_dir, 'data')
    test_set_label_path = os.path.join(test_set_dir, 'labels')
    # 引入了归一化之后的数据
    test_set = tools.IMG_Dataset(data_dir=test_set_img_dir,
                                 label_path=test_set_label_path, transforms=data_transform)
    test_set_loader = torch.utils.data.DataLoader(
        test_set,
        batch_size=batch_size, shuffle=False, worker_init_fn=tools.worker_init, **kwargs)

    # Poison Transform for Testing
    poison_transform = supervisor.get_poison_transform(poison_type=args.poison_type, dataset_name=args.dataset,
                                                       target_class=config.target_class[args.dataset],
                                                       trigger_transform=data_transform,
                                                       is_normalized_input=True,
                                                       alpha=args.alpha if args.test_alpha is None else args.test_alpha,
                                                       trigger_name=args.trigger, args=args)


elif args.dataset == 'imagenet':

    poison_transform = imagenet.get_poison_transform_for_imagenet(args.poison_type)

    test_set = imagenet.imagenet_dataset(directory=test_set_dir, shift=False, aug=False,
                                         label_file=imagenet.test_set_labels, num_classes=1000)
    test_set_backdoor = imagenet.imagenet_dataset(directory=test_set_dir, shift=False, aug=False,
                                                  label_file=imagenet.test_set_labels, num_classes=1000,
                                                  poison_transform=poison_transform)

    test_split_meta_dir = os.path.join('clean_set', args.dataset, 'test_split')
    test_indices = torch.load(os.path.join(test_split_meta_dir, 'test_indices'))

    test_set = torch.utils.data.Subset(test_set, test_indices)
    test_set_loader = torch.utils.data.DataLoader(
        test_set,
        batch_size=batch_size, shuffle=False, worker_init_fn=tools.worker_init, **kwargs)

    test_set_backdoor = torch.utils.data.Subset(test_set_backdoor, test_indices)
    test_set_backdoor_loader = torch.utils.data.DataLoader(
        test_set_backdoor,
        batch_size=batch_size, shuffle=False, worker_init_fn=tools.worker_init, **kwargs)

else:
    normalizer = poisoned_set.normal

    test_set_dir = os.path.join('clean_set', args.dataset, 'test_split')

    test_set = tools.EMBER_Dataset(x_path=os.path.join(test_set_dir, 'X.npy'),
                                   y_path=os.path.join(test_set_dir, 'Y.npy'),
                                   normalizer=normalizer)

    test_set_loader = torch.utils.data.DataLoader(
        test_set,
        batch_size=batch_size, shuffle=False, worker_init_fn=tools.worker_init, **kwargs)

    backdoor_test_set_dir = os.path.join('poisoned_train_set', 'ember', args.ember_options)
    backdoor_test_set = tools.EMBER_Dataset(x_path=os.path.join(poison_set_dir, 'watermarked_X_test.npy'),
                                            y_path=None, normalizer=normalizer)
    backdoor_test_set_loader = torch.utils.data.DataLoader(
        backdoor_test_set,
        batch_size=batch_size, shuffle=False, worker_init_fn=tools.worker_init, **kwargs)


# test the model
# 初始化模
if args.dataset != 'ember':
    model = arch(num_classes=num_classes)
else:
    model = arch()

#model = nn.DataParallel(model)
model.eval()


def certificate_over_dataset(model, num_classes, dataloader, args, N_m = args.N_m):
    model_preds = []
    labs = []
    model.cuda()
    softmax = nn.Softmax(dim= 1)
    with torch.no_grad():
        for _ in tqdm(range(N_m)):
            # 加载第_个模型
            model.load_state_dict(torch.load(supervisor.get_poison_set_dir(args) + '/smoothed_%d.pt' %_))
            all_pred = np.zeros((0, num_classes))

            # 遍历数据集
            for x_in, y_in in dataloader:

                if _ == 0:
                    labs = labs + list(y_in.numpy())

                # 获得模型的预测向量
                x_in = x_in.cuda()
                pred = model(x_in)
                pred = softmax(pred)
                # 将一个模型所有的预测结果concatenate到一起
                all_pred = np.concatenate([all_pred, pred.cpu().detach().numpy()], axis=0)

            # 保存每个模型对于所有样本的预测结果，存储到model_preds列表中
            model_preds.append(all_pred)

    if args.inference_method == 'probability_scores':
        # 计算平均预测概率
        gx = np.array(model_preds).mean(0)

        labs = np.array(labs)

        # 计算每个样本中最高的预测概率
        pa = gx.max(1)
        # 得到预测标签
        pred_c = gx.argmax(1)
        # 将最大预测概率设置为-1，便于后续计算次大预测概率
        gx[np.arange(len(pred_c)), pred_c] = -1
        # 计算每个样本的次大概率
        pb = gx.max(1)
        # 判断模型的预测是否正确，返回一个Boolean数组，True表示预测正确，False表示预测错误
        is_acc = (pred_c == labs)

    elif args.inference_method == 'multinomial_label':



    return pa, pb, is_acc

def apply_poison_transform(data_loader, poison_transform):
    for data, labels in data_loader:
        # 应用毒化变换到每个样本上
        poison_data_list = []
        for i in range(data.size(0)):
            poison_data, _ = poison_transform.transform(data[i],torch.tensor([labels[i]]),dataset_name = args.dataset)
            poison_data_list.append(poison_data.unsqueeze(0))

        # 将处理后的数据重新组成一个批次
        poisoned_batch = torch.cat(poison_data_list, dim=0)
        yield poisoned_batch, labels


poisoned_test_loader = apply_poison_transform(test_set_loader, poison_transform)


pa_exp, pb_exp, is_acc = certificate_over_dataset(model=model, num_classes= num_classes,
                                                  dataloader= test_set_loader, args = args, N_m= args.N_m)

if args.confi_interval_metod == 'heof':
    # 以下步骤应用Hoeffding 不等式，生成置信区间的上下界，使用双边完整的置信度eta进行实验
    heof_factor = np.sqrt(np.log(1/args.eta)/2/args.N_m)

    # 给出PA的下界和PB的上界
    pa = np.maximum(1e-8, pa_exp - heof_factor)
    pb = np.minimum(1-1e-8, pb_exp + heof_factor)

    # Calculate the metrics
    # 当前计算的是总的鲁棒半径
    if args.certified_method == 'hypothesis':
        print("训练集中有多少条中毒样本：")
        print(len(poison_indices))

        cert_bound = 0.5 * args.input_sigma * (norm.ppf(pa) - norm.ppf(pb)) / np.sqrt(len(poison_indices))
        cert_bound_exp = 0.5 * args.input_sigma * (norm.ppf(pa_exp) - norm.ppf(pb_exp) / np.sqrt(len(poison_indices))
                                                ) # Also calculate the bound using expected value.

    cert_acc = []
    cond_acc = []
    cert_ratio = []
    cert_acc_exp = []
    cond_acc_exp = []
    cert_ratio_exp = []
    # rad 是不同的鲁棒半径
    rad = args.rad
    for r in rad:
        # np.logical_and用于逐元素的对两个数组执行“与”操作，cert_acc表示的是总鲁棒半径大于r且分类准确的概率
        cert_acc.append(np.logical_and(cert_bound > r, is_acc).mean())
        # 条件认证准确率，表示在所有认证半径大于r的样本中，有多少样本的分类是正确的
        cond_acc.append(np.logical_and(cert_bound > r, is_acc).sum() / (cert_bound > r).sum())
        # 表示认证半径大于r的样本占总比例
        cert_ratio.append((cert_bound > r).mean())

        cert_acc_exp.append(np.logical_and(cert_bound_exp > r, is_acc).mean())
        cond_acc_exp.append(np.logical_and(cert_bound_exp > r, is_acc).sum() / (cert_bound_exp > r).sum())
        cert_ratio_exp.append((cert_bound_exp > r).mean())

    print("Certified Radius:", ' / '.join([str(r) for r in rad]))
    print("Cert acc:", ' / '.join(['%.5f' % x for x in cert_acc]))
    print("Cond acc:", ' / '.join(['%.5f' % x for x in cond_acc]))
    print("Cert ratio:", ' / '.join(['%.5f' % x for x in cert_ratio]))
    print("Expected Cert acc:", ' / '.join(['%.5f' % x for x in cert_acc_exp]))
    print("Expected Cond acc:", ' / '.join(['%.5f' % x for x in cond_acc_exp]))
    print("Expected Cert ratio:", ' / '.join(['%.5f' % x for x in cert_ratio_exp]))


# for _ in range(args.N_m):
#
#
#
#     if args.dataset != 'ember':
#         print(f"Will save to '{supervisor.get_model_dir(args)}'.")
#         if os.path.exists(supervisor.get_model_dir(args)):
#             print(f"Model '{supervisor.get_model_dir(args)}' already exists!")
#
#         if args.dataset == 'imagenet':
#             criterion = nn.CrossEntropyLoss().cuda()
#         else:
#             criterion = nn.CrossEntropyLoss().cuda()
#     else:
#         model_path = os.path.join('poisoned_train_set', 'ember', args.ember_options, 'full_base_aug_seed=%d.pt' % args.seed)
#         print(f"Will save to '{model_path}'.")
#         if os.path.exists(model_path):
#             print(f"Model '{model_path}' already exists!")
#         criterion = nn.BCELoss().cuda()
#
#     optimizer = torch.optim.SGD(model.parameters(), learning_rate, momentum=momentum, weight_decay=weight_decay)
#     scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=milestones)
#
#     if args.poison_type == 'TaCT' or args.poison_type == 'SleeperAgent':
#         source_classes = config.source_class
#     else:
#         source_classes = None
#
#     import time
#
#     st = time.time()
#
#     # scaler = GradScaler()
#     for epoch in range(1, epochs + 1):  # train backdoored base model
#         start_time = time.perf_counter()
#
#         # Train
#         model.train()
#         preds = []
#         labels = []
#         for data, target in tqdm(poisoned_set_loader):
#             data = data.cuda()
#             target = target.cuda()
#
#             data, target = data.cuda(), target.cuda()
#             optimizer.zero_grad()
#
#             # with autocast():
#             output = model(data)
#             loss = criterion(output, target)
#
#             # scaler.scale(loss).backward()
#             # scaler.step(optimizer)
#             # scaler.update()
#
#             loss.backward()
#             optimizer.step()
#
#         end_time = time.perf_counter()
#         elapsed_time = end_time - start_time
#         print('<Backdoor Training> Train Epoch: {} \tLoss: {:.6f}, lr: {:.6f}, Time: {:.2f}s'.format(epoch, loss.item(),
#                                                                                                      optimizer.param_groups[
#                                                                                                          0]['lr'],
#                                                                                                      elapsed_time))
#         scheduler.step()
#
#         # Test
#
#         if args.dataset != 'ember':
#             if True:
#                 if epoch % 5 == 0:
#                     if args.dataset == 'imagenet':
#                         tools.test_imagenet(model=model, test_loader=test_set_loader,
#                                             test_backdoor_loader=test_set_backdoor_loader)
#                         torch.save(model.module.state_dict(), supervisor.get_model_dir(args))
#                     else:
#                         tools.test(dataset_name = args.dataset, model=model, test_loader=test_set_loader, poison_test=True,
#                                    poison_transform=poison_transform, num_classes=num_classes, source_classes=source_classes,
#                                    all_to_all=all_to_all)
#                         torch.save(model.module.state_dict(), supervisor.get_poison_set_dir(args) + '/smoothed_%d.pt' %_)
#
#                 # if epoch == 15:
#                 #     torch.save(model.module.state_dict(),
#                 #                f"./poisoned_train_set/gtsrb/adaptive_patch_0.020_cover=0.005_poison_seed=0/full_base_aug_seed=2333_15epochs.pt")
#         else:
#
#             tools.test_ember(model=model, test_loader=test_set_loader,
#                              backdoor_test_loader=backdoor_test_set_loader)
#             torch.save(model.module.state_dict(), model_path)
#         print("")
#
#     if args.dataset != 'ember':
#         torch.save(model.module.state_dict(), supervisor.get_model_dir(args))
#     else:
#         torch.save(model.module.state_dict(), model_path)
#
#     if args.poison_type == 'none':
#         if args.no_aug:
#             torch.save(model.module.state_dict(), f'models/{args.dataset}_vanilla_no_aug.pt')
#             torch.save(model.module.state_dict(), f'models/{args.dataset}_vanilla_no_aug_seed={args.seed}.pt')
#         else:
#             torch.save(model.module.state_dict(), f'models/{args.dataset}_vanilla_aug.pt')
#             torch.save(model.module.state_dict(), f'models/{args.dataset}_vanilla_aug_seed={args.seed}.pt')