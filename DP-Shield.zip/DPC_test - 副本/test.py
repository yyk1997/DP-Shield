import numpy as np
from scipy.special import comb

# Given values
q = 0.2
r = 100

# Calculate the sum inside the logarithm
sum_value = (1 - q) ** r
Delta = 1e-5
Delta_total = 0

for i in range(1, r+1):
    sum_value += comb(r, r-i) * ((1 - q)**(r-i)) * (q**i) * np.exp(i * 0.08)
    Delta_total += comb(r, r-i) * (1 - q)**(r-i) * (q**i) * Delta

# Compute the natural logarithm of the result
# result = np.log(sum_value)
print(sum_value)
print(Delta_total)